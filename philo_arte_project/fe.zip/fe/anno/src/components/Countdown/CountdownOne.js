import React from "react";
import Countdown from "react-countdown";
import parse from "html-react-parser";

const CountdownOne = ({ title, tagline, backfont }) => {
  const renderer = ({ days, hours, minutes, seconds }) => {
    return (
      <ul className="countdown">
        <li>
          <span className="days default-color font-30px font-700">{days}</span>
          <p className="dark-color font-600">days </p>
        </li>
        <li>
          <span className="hours default-color font-30px font-700">
            {hours}
          </span>
          <p className="dark-color font-600">hours </p>
        </li>
        <li>
          <span className="minutes default-color font-30px font-700">
            {minutes}
          </span>
          <p className="dark-color font-600">minutes</p>
        </li>
        <li>
          <span className="seconds default-color font-30px font-700">
            {seconds}
          </span>
          <p className="dark-color font-600">seconds</p>
        </li>
      </ul>
    );
  };

  return (
    <section className="white-bg">
      <div className="container">
        <div className="row">
          <div className="col-md-8 col-sm-8 centerize-col">
            <div className="section-title text-center">
              <h2
                className="cardo-font default-color"
                data-backfont={backfont || "Countdown"}
              >
                {tagline}
              </h2>
              <h1>{title && parse(title)}</h1>
            </div>
          </div>
        </div>
        <div className="row mt-50">
          <div className="col-md-12 text-center">
            <div className="countdown-container mt-0 mb-0">
              <Countdown
                date={Date.now() + (28 * 24 * 60 * 60000 + 41500000)}
                renderer={renderer}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CountdownOne;
