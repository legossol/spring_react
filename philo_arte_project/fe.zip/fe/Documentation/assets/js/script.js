$(document).ready(function () {
  // make code pretty
  window.prettyPrint && prettyPrint();
//   $("pre code").each(function (i, block) {
//     hljs.highlightBlock(block);
//   });
});
